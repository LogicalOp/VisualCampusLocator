
const Home = () => {
    return (
        <>
        <title>Home Page</title>
        </>
    );
};

export default Home;
